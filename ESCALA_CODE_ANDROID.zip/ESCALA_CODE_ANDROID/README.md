# ESCALA CODE — proyecto Android nativo

Versión inicial del proyecto Android nativo para Android 6.0+ (probado como objetivo de compatibilidad; todavía requiere compilación y prueba en un dispositivo real).

## Funciones incluidas
- Lista de aplicaciones de usuario instaladas y búsqueda por nombre/paquete.
- Extracción del APK instalado desde `ApplicationInfo.sourceDir`.
- Detección de aplicaciones divididas mediante `splitSourceDirs`.
- Para una app de APK único: exporta un `.apk`.
- Para una app dividida: copia `base.apk` y todos los splits en un `.zip` de respaldo.
- Subida multipart directa a `https://upload.gofile.io/uploadfile` con progreso.
- Copia de la URL pública y apertura de AFTVnews para que el usuario complete su CAPTCHA y genere el código Downloader.
- Guardado local del código ingresado por el usuario.

## Límites importantes
1. La app no evade el CAPTCHA de AFTVnews ni inventa códigos. El usuario debe completar el flujo oficial.
2. Un APK dividido no se convierte mágicamente en un APK universal. El ZIP contiene todas las partes para respaldo; no es instalable directamente con un código Downloader estándar. Para distribución de un solo archivo se necesita que el desarrollador proporcione un APK universal/standalone, o distribuir el paquete dividido mediante un instalador compatible.
3. La app solicita `QUERY_ALL_PACKAGES` para listar las apps instaladas. Google Play restringe el uso de este permiso; este proyecto está pensado para instalación directa/sideload si el usuario acepta el permiso declarado.
4. La subida de invitado depende de la disponibilidad, políticas y límites actuales de Gofile. El enlace puede tener condiciones de retención propias del servicio.
5. El proyecto fue generado como código fuente. No se afirma que el APK haya sido compilado ni probado en el Moto G13.

## Compilar sin instalar Android Studio en el teléfono
El repositorio incluye `.github/workflows/build-apk.yml`. Al subir estos archivos a un repositorio GitHub en la rama `main` o `master`, GitHub Actions compila `app-debug.apk` en la nube y publica el APK como artifact de la ejecución.

Pasos generales desde el teléfono:
1. Crear un repositorio vacío en GitHub.
2. Subir el contenido de esta carpeta manteniendo las rutas.
3. Abrir la pestaña **Actions** del repositorio y ejecutar **Build ESCALA CODE APK** (o esperar al build automático tras el push).
4. Abrir la ejecución terminada, descargar el artifact `ESCALA-CODE-debug-apk` y extraer `app-debug.apk`.
5. Instalarlo en Android autorizando la instalación desde el navegador/gestor de archivos cuando el sistema lo solicite.

## Tecnología
- Kotlin
- Android Gradle Plugin 8.7.3
- Kotlin Android plugin 2.0.21
- Gradle 8.9
- compileSdk 35 / minSdk 23 / targetSdk 35
