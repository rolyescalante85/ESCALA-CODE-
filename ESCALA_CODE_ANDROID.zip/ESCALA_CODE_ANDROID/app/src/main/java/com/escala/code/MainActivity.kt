package com.escala.code

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val apps = mutableListOf<ApplicationInfo>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var progress: ProgressBar
    private lateinit var urlText: TextView
    private lateinit var codeInput: EditText
    private var selected: ApplicationInfo? = null
    private var exported: File? = null
    private var publicUrl: String = ""
    private val gold = Color.rgb(212, 175, 55)
    private val bg = Color.rgb(7, 8, 12)
    private val panel = Color.rgb(19, 21, 29)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        loadApps()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(18), dp(18), dp(18)) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = TextView(this).apply { text = "ESCALA CODE"; textSize = 27f; setTextColor(gold); gravity = Gravity.CENTER; setTypeface(null, 1); letterSpacing = .12f }
        content.addView(brand, matchWrap())
        content.addView(label("EXTRACTOR ANDROID · PRO"), matchWrap())
        content.addView(label("Elegí una aplicación instalada, extraé sus archivos APK y subilos a Gofile."), matchWrap())
        search = EditText(this).apply { hint = "Buscar aplicación…"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(0xff8d93a1.toInt()); setBackgroundColor(panel) }
        content.addView(search, matchWrap(dp(48)))
        search.addTextChangedListener(SimpleWatcher { renderApps(it) })
        val reload = button("ACTUALIZAR LISTA") { loadApps() }
        content.addView(reload, matchWrap())
        val heading = label("APLICACIONES INSTALADAS").apply { setPadding(0, dp(16), 0, dp(8)); setTextColor(gold) }
        content.addView(heading, matchWrap())
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list, matchWrap())
        content.addView(label("PASO 2 · EXPORTAR Y SUBIR").apply { setTextColor(gold); setPadding(0, dp(20), 0, dp(6)) }, matchWrap())
        content.addView(button("EXTRAER APK SELECCIONADA") { extractSelected() }, matchWrap())
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressTintList = android.content.res.ColorStateList.valueOf(gold) }
        content.addView(progress, matchWrap(dp(8)))
        content.addView(button("SUBIR A GOFILE") { uploadExported() }, matchWrap())
        status = label("Listo. Seleccioná una aplicación para comenzar.")
        status.setPadding(0, dp(10), 0, dp(10))
        content.addView(status, matchWrap())
        content.addView(label("URL PÚBLICA DE GOFILE").apply { setTextColor(gold) }, matchWrap())
        urlText = label("Todavía no hay un enlace.")
        content.addView(urlText, matchWrap())
        content.addView(button("COPIAR URL") { copy(publicUrl) }, matchWrap())
        content.addView(button("ABRIR AFTVNEWS") { openAftv() }, matchWrap())
        content.addView(label("PASO 3 · CÓDIGO DOWNLOADER").apply { setTextColor(gold); setPadding(0, dp(18), 0, dp(4)) }, matchWrap())
        content.addView(label("AFTVnews requiere que completes su CAPTCHA y generes el código. ESCALA CODE no omite esa verificación.").apply { textSize = 12f }, matchWrap())
        codeInput = EditText(this).apply { hint = "Código numérico"; inputType = 2; setTextColor(Color.WHITE); setHintTextColor(0xff8d93a1.toInt()); setBackgroundColor(panel) }
        content.addView(codeInput, matchWrap(dp(50)))
        content.addView(button("GUARDAR CÓDIGO") {
            val c = codeInput.text.toString().trim()
            if (!c.matches(Regex("\\d{4,10}"))) toast("Ingresá un código de 4 a 10 dígitos")
            else { getSharedPreferences("codes", MODE_PRIVATE).edit().putString(publicUrl, c).apply(); toast("Código guardado en este teléfono") }
        }, matchWrap())
        content.addView(label("Nota: los APK divididos se exportan como ZIP con todas sus partes. Ese ZIP es una copia de respaldo; no es instalable directamente mediante un código Downloader estándar. Para generar un código de instalación directa se necesita un APK universal o un APK único.").apply { textSize = 11f; setTextColor(0xffb7bac4.toInt()); setPadding(0, dp(16), 0, dp(20)) }, matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadApps() {
        status.text = "Leyendo aplicaciones instaladas…"
        worker.execute {
            val found = packageManager.getInstalledApplications(0)
                .filter { it.packageName != packageName && (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }
            runOnUiThread { apps.clear(); apps.addAll(found); renderApps(search.text.toString()); status.text = "${apps.size} aplicaciones disponibles." }
        }
    }

    private fun renderApps(query: String) {
        if (!::list.isInitialized) return
        list.removeAllViews()
        apps.filter { packageManager.getApplicationLabel(it).toString().contains(query, true) || it.packageName.contains(query, true) }
            .take(250).forEach { app ->
                val name = packageManager.getApplicationLabel(app).toString()
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(panel) }
                val icon = ImageView(this).apply { setImageDrawable(packageManager.getApplicationIcon(app)) }
                row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
                val info = TextView(this).apply { text = "$name\n${app.packageName}"; textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(10), 0, dp(6), 0) }
                row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                val choose = Button(this).apply { text = if (selected?.packageName == app.packageName) "ELEGIDA" else "ELEGIR"; setTextColor(gold); setOnClickListener { selected = app; renderApps(search.text.toString()); status.text = "Seleccionada: $name" } }
                row.addView(choose)
                val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(5); list.addView(row, lp)
            }
    }

    private fun extractSelected() {
        val app = selected ?: run { toast("Primero elegí una aplicación"); return }
        status.text = "Extrayendo archivos de ${packageManager.getApplicationLabel(app)}…"
        progress.progress = 0
        worker.execute {
            try {
                val base = File(app.sourceDir)
                val splits = app.splitSourceDirs?.map { File(it) } ?: emptyList()
                val all = listOf(base) + splits
                val dir = File(getExternalFilesDir(null), "exports").apply { mkdirs() }
                val safe = packageManager.getApplicationLabel(app).toString().replace(Regex("[^A-Za-z0-9._-]"), "_")
                val out = if (all.size == 1) File(dir, "$safe.apk") else File(dir, "$safe-APKS.zip")
                if (all.size == 1) base.copyTo(out, overwrite = true)
                else ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zip ->
                    all.forEachIndexed { index, file ->
                        zip.putNextEntry(ZipEntry(if (index == 0) "base.apk" else "split_${index}.apk"))
                        FileInputStream(file).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
                exported = out
                runOnUiThread { status.text = "Exportado: ${out.name} · ${out.length() / 1024 / 1024} MB. Ya podés subirlo."; toast("Extracción completada") }
            } catch (e: Exception) { runOnUiThread { status.text = "Error al extraer: ${e.message}" } }
        }
    }

    private fun uploadExported() {
        val file = exported ?: run { toast("Primero extraé una aplicación"); return }
        if (!file.exists()) { toast("El archivo exportado ya no existe. Volvé a extraerlo."); return }
        status.text = "Conectando con Gofile…"; progress.progress = 0
        worker.execute {
            var conn: HttpURLConnection? = null
            try {
                val boundary = "EscalaCode-${System.currentTimeMillis()}"
                conn = (URL("https://upload.gofile.io/uploadfile").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; doOutput = true; connectTimeout = 30000; readTimeout = 120000
                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                }
                conn.outputStream.use { raw ->
                    val out = BufferedOutputStream(raw)
                    out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"${file.name}\"\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray())
                    FileInputStream(file).use { input ->
                        val buf = ByteArray(64 * 1024); var sent = 0L; var n: Int
                        while (input.read(buf).also { n = it } > 0) {
                            out.write(buf, 0, n); sent += n
                            val pct = ((sent * 100) / file.length()).toInt()
                            runOnUiThread { progress.progress = pct; status.text = "Subiendo a Gofile… $pct%" }
                        }
                    }
                    out.write("\r\n--$boundary--\r\n".toByteArray()); out.flush()
                }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                if (code !in 200..299 || json.optString("status") != "ok") throw Exception(json.optString("message", "Gofile rechazó la subida"))
                val data = json.optJSONObject("data") ?: JSONObject()
                val link = data.optString("downloadPage").ifBlank { data.optString("directLink") }.ifBlank { data.optString("downloadUrl") }
                if (link.isBlank()) throw Exception("Gofile no devolvió una URL pública")
                publicUrl = link
                runOnUiThread { urlText.text = link; status.text = "Subida completada. URL lista para AFTVnews."; progress.progress = 100; copy(link) }
            } catch (e: Exception) { runOnUiThread { status.text = "Error de subida: ${e.message}" } }
            finally { conn?.disconnect() }
        }
    }

    private fun openAftv() {
        if (publicUrl.isBlank()) { toast("Primero subí un archivo a Gofile"); return }
        copy(publicUrl)
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://go.aftvnews.com/")))
        toast("URL copiada. Pegala en AFTVnews y completá el CAPTCHA.")
    }

    private fun copy(value: String) {
        if (value.isBlank()) { toast("Todavía no hay contenido para copiar"); return }
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ESCALA CODE", value))
        toast("Copiado al portapapeles")
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply { this.text = text; setTextColor(gold); setOnClickListener { action() } }
    private fun label(text: String) = TextView(this).apply { this.text = text; textSize = 13f; setTextColor(0xffe8e8ec.toInt()); setPadding(0, dp(5), 0, dp(5)) }
    private fun matchWrap(h: Int = -2) = LinearLayout.LayoutParams(-1, h).apply { bottomMargin = dp(7) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
